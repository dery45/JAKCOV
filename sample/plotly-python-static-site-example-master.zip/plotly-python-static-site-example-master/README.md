# plotly-python-static-site-example

This is a very basic example of how to render Plotly charts as static html files.

Each plot is rendered as a separate iframe. Plotly Javascript code is loaded from their CDN (this is configurable).

[Live demo here](https://plotly-static-html.netlify.app/).